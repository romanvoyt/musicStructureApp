package com.example.android.musicapp;

import android.content.res.Resources;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;
import java.util.ArrayList;

public class Rock extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.song_list);

        Resources res = getResources();
        String[] artistNames = res.getStringArray(R.array.rock_artists_array);
        String[] songNames = res.getStringArray(R.array.rock_songs_array);

        ArrayList<Song> rockSongs = new ArrayList<Song>();

        for(int i = 0; i < artistNames.length; i++){
            rockSongs.add(new Song(artistNames[i], songNames[i]));
        }

        SongAdapter itemAdapter = new SongAdapter(this, rockSongs);

        ListView listView = (ListView)findViewById(R.id.list);
        listView.setAdapter(itemAdapter);
    }
}
