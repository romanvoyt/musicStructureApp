package com.example.android.musicapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.view.View;
import android.widget.LinearLayout;

public class MainActivity extends AppCompatActivity {
    LinearLayout mainLinearLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        CardView jazzCathegory = (CardView)findViewById(R.id.jazz);
        jazzCathegory.setOnClickListener(new CardView.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent jazzIntent = new Intent(MainActivity.this, Jazz.class);
                startActivity(jazzIntent);
            }

        });

        CardView classicalCathergory = (CardView)findViewById(R.id.classic);
        classicalCathergory.setOnClickListener(new CardView.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent classicalIntent = new Intent(MainActivity.this, Classic.class);
                startActivity(classicalIntent);
            }

        });

        CardView hipHopCathergory = (CardView)findViewById(R.id.hip_hop);
        hipHopCathergory.setOnClickListener(new CardView.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent hipHopIntent = new Intent(MainActivity.this, HipHop.class);
                startActivity(hipHopIntent);
            }

        });

        CardView rockCathegory = (CardView)findViewById(R.id.rock);
        rockCathegory.setOnClickListener(new CardView.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent rockIntent = new Intent(MainActivity.this, Rock.class);
                startActivity(rockIntent);
            }

        });


    }
}
