package com.example.android.musicapp;

import android.content.res.Resources;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;
import java.util.ArrayList;

public class Jazz extends AppCompatActivity{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.song_list);

        Resources res = getResources();
        String[] artistNames = res.getStringArray(R.array.jazz_artists_array);
        String[] songNames = res.getStringArray(R.array.jazz_songs_array);

        ArrayList<Song> jazzSongs = new ArrayList<Song>();

        for(int i = 0; i < artistNames.length; i++){
            jazzSongs.add(new Song(artistNames[i], songNames[i]));
        }

        SongAdapter itemAdapter = new SongAdapter(this, jazzSongs);

        ListView listView = (ListView)findViewById(R.id.list);
        listView.setAdapter(itemAdapter);
    }
}
